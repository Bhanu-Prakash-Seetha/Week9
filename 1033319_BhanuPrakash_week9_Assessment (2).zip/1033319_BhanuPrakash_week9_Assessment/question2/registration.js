var textDom = document.getElementById("name");
var emailDom = document.getElementById("email");
var areaDom = document.getElementById("tarea");
function mybtn(){
    values = textDom.value;
    values1=emailDom.value;
    values2=areaDom.value;
    const emailtext = /[@.]/.test(values1);
    const nametext = /[a-zA-Z]/;
    if(emailtext){

    }else{
        var valid = "*Email contains @ and .";
        document.getElementById("emailid").innerHTML=valid;
    }
    if(values=="" && values2==""){
        var valid = "*Cannot be empty";
        document.getElementById("namevalid").innerHTML=valid;
        document.getElementById("areavalid").innerHTML=valid;
    }
  
}