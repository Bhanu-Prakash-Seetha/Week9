var a = ["spray", "limit", "Pioneer", "exuberant", "destruction", "Infinite"];
const output = a.filter((a)=>a.length>7);
console.log(output);